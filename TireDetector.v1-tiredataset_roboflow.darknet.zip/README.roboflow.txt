
TireDetector - v1 TireDataset_roboflow
==============================

This dataset was exported via roboflow.ai on April 18, 2021 at 10:23 AM GMT

It includes 2416 images.
Tires are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Fit (black edges))

The following augmentation was applied to create 2 versions of each source image:
* Random brigthness adjustment of between 0 and +40 percent


